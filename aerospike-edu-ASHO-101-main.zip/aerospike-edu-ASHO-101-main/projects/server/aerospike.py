#TODO import Aerospike client

#TODO write a record to the database

#TODO read a record from the database

#TODO update a record in the database

#TODO delete a record from the database

#TODO query records in the database

#TODO batch write records to the database

#TODO batch read records from the database

#TODO batch update records in the database

#TODO batch delete records from the database
